import datetime
import time
from snappy import ProductIO
from snappy import HashMap
import os, gc
from snappy import GPF

op_spi = GPF.getDefaultInstance().getOperatorSpiRegistry().getOperatorSpi('Resample')
print('Op name:', op_spi.getOperatorDescriptor().getName())
print('Op alias:', op_spi.getOperatorDescriptor().getAlias())
param_Desc = op_spi.getOperatorDescriptor().getParameterDescriptors()
for param in param_Desc:
    print(param.getName(), "or", param.getAlias(), "and" , param.getDataType())
