import time
import os
import snappy
from glob import iglob
from os.path import join


def convert_sec_min(seconds):
    min, sec = divmod(seconds, 60)
    return '%02d:%02d' % (min, sec)


def do_topsar_split(source, sub_swath, firsr_burst, last_burst):
    parameters = snappy.HashMap()
    parameters.put('subswath', sub_swath)
    parameters.put('firstBurstIndex', firsr_burst)
    parameters.put('lastBurstIndex', last_burst)
    output = snappy.GPF.createProduct('TOPSAR-Split', parameters, source)
    return output


def apply_orbital_file(source):
    parameters = snappy.HashMap()
    parameters.put('orbitType', 'Sentinel Precise (Auto Download)')
    parameters.put('polyDegree', 3) 
    output = snappy.GPF.createProduct('Apply-Orbit-File', parameters, source)
    return output


def do_calibration(source):
    parameters = snappy.HashMap()
    parameters.put('outputImageInComplex', 'true')
    output = snappy.GPF.createProduct("Calibration", parameters, source)
    return output


def do_TOPS_Debust(source):
    parameters = snappy.HashMap()
    output = snappy.GPF.createProduct("TOPSAR-Deburst", parameters, source)
    return output


def do_c2matrix(source):
    parameters = snappy.HashMap()
    parameters.put('matrix','C2')
    output = snappy.GPF.createProduct("Polarimetric-Matrices", parameters, source)
    return output


def do_multilook(source):
    parameters = snappy.HashMap()
    parameters.put('sourceBandNames','C11,C22')
    parameters.put('nRgLooks', 2)
    parameters.put('nAzLooks', 1)
    parameters.put('outputIntensity', 'false')
    parameters.put('grSquarePixel', 'ture')
    output = snappy.GPF.createProduct("Multilook", parameters, source)
    return output


def do_bandmath_addband(source):
    snappy.GPF.getDefaultInstance().getOperatorSpiRegistry().loadOperatorSpis()
    BandDescriptor = snappy.jpy.get_type('org.esa.snap.core.gpf.common.BandMathsOp$BandDescriptor')

    targetBand1 = BandDescriptor()
    targetBand1.name = 'C11.bin'
    targetBand1.type = 'float32'
    targetBand1.expression = 'C11 * 1'

    targetBand2 = BandDescriptor()
    targetBand2.name = 'C22.bin'
    targetBand2.type = 'float32'
    targetBand2.expression = 'C22 * 1'

    targetBand3 = BandDescriptor()
    targetBand3.name = 'entropy_shannon_norm.bin'
    targetBand3.type = 'float32'
    targetBand3.expression = 'C11 * 1'

    targetBand4 = BandDescriptor()
    targetBand4.name = 'Raney_Rnd.bin'
    targetBand4.type = 'float32'
    targetBand4.expression = 'C11 * 1'
   
    targetBands = snappy.jpy.array('org.esa.snap.core.gpf.common.BandMathsOp$BandDescriptor', 4)
    targetBands[0] = targetBand1
    targetBands[1] = targetBand2
    targetBands[2] = targetBand3
    targetBands[3] = targetBand4

    parameters = snappy.HashMap()
    parameters.put('targetBands', targetBands)

    output = snappy.GPF.createProduct('BandMaths', parameters, source)
    return output

def snap_processing(zip_file_path, output_folder, sub_swath, firsr_burst, last_burst):

    
    print(zip_file_path)

    zip_file_name = zip_file_path.split("/")[-1]
    
    
    st = time.time()
    product_s1 = snappy.ProductIO.readProduct(zip_file_path)

    
    PolSARPro_output = output_folder + "/polsar_output/" + zip_file_name.split(".")[0] + "_" +  sub_swath+"_Orb_Cal_Deb.hdr"
    final_output = output_folder + "/" +zip_file_name.split(".")[0] + "_" + sub_swath+ "_Orb_Cal_Deb_ML.dim"
    
    topsar_split_out = do_topsar_split(product_s1, sub_swath, firsr_burst, last_burst)
    apply_orbital_file_out = apply_orbital_file(topsar_split_out)
    calibration_out = do_calibration(apply_orbital_file_out)
    TOPS_Debust_out = do_TOPS_Debust(calibration_out)

    snappy.ProductIO.writeProduct(TOPS_Debust_out,PolSARPro_output , 'PolSARPro')

    c2matrix_out = do_c2matrix(TOPS_Debust_out)
    multilook_out = do_multilook(c2matrix_out)
    bandmath_addband_out = do_bandmath_addband(multilook_out)

    snappy.ProductIO.writeProduct(bandmath_addband_out,final_output, 'BEAM-DIMAP')

    et = time.time()
    elapsed_time = et - st
    print('Scene processed in:', convert_sec_min(elapsed_time), 'min')

'''
# Read
product_path = r'D:\snappy_process\slc_sen1'
input_S1_files = sorted(list(iglob(join(product_path, '**', '*S1*.zip'),
                                   recursive=True)))

print(input_S1_files[0])

os.chdir(r'D:\snappy_process')

snap_processing(input_S1_files[1], "IW1", 1, 3)

'''

