import os
import pandas as pd
from sentinelsat import SentinelAPI, read_geojson, geojson_to_wkt
from datetime import date
from snap_processing_pipeline import snap_processing


myusername = 'shubham6147'
mypassword = 'Shubham@4475'


api = SentinelAPI(myusername, mypassword)

#api = SentinelAPI('user', 'password', 'https://apihub.copernicus.eu/apihub')

scene_processing = pd.read_csv(r"C:\Users\shubh\Downloads\kalahandi_json_intersection.csv")


#scene_processing_filter = scene_processing[scene_processing["Unique_id"]== 131919]

print(scene_processing)

import glob, os
input_path = "D:/snappy_process/251022"
os.chdir(input_path)

for file in glob.glob("*.zip"):
    #print(file)

    zip_name = file.split(".")[0]
    print(zip_name)
    scene_processing_filtered = scene_processing[scene_processing["scene"]== zip_name]

    print(scene_processing_filtered)


    for index, row in scene_processing_filtered.iterrows():
        prod_name = row["scene"]+'.zip'
        print(prod_name)
        input_path = "D:/snappy_process/251022"
        os.chdir(input_path)
        
        #api.download( row["scene_uuid"])
        print("downloaded product :" , prod_name )

        zip_file_path = input_path + "/"+ row["scene"]+'.zip'
        output_folder = 'D:/snappy_process/251022_processing'
        sub_swath = 'IW1'
        firsr_burst = 8 #7 row["IW1_min"]
        last_burst = 9 #row["IW1_max"]
        
        snap_processing(zip_file_path, output_folder, sub_swath, firsr_burst, last_burst)


    

    
